import os
import wget

class downloader():
    def __init__(self,force=False):

        url = 'https://github.com/klauslippert/person-name-normalisation/raw/main/NaiveBayes_on_names/data/result/p_firstname.p'
        file='p_firstname.p'
        path = '/'.join(__file__.split('/')[:-1])+'/'
        pathfile = path+file
        
        fileexist = os.path.isfile(pathfile)
        
        if force:
            fileexist=False
            _=os.remove(pathfile)
        else:
            pass
        
        if fileexist:
            pass            
        else:
            if force:
                print('Forced download (and replacement) of p values')
            else:
                print('First time starting personnamenorm -> download p values')
            _  = wget.download(url,path+file)
            
        
        
        
        
